#!/usr/bin/env python3
"""BulbBee BLE GATT lighting-control server (the Android app's channel).

BULB-A1 functional bring-up, no intentional weakness. Modeled on CareOtter's
ble_server.py (dbus-fast over the BlueZ system bus). This is a BLE front-end
over the localhost HTTP lighting service on :8082 (BULB-A0), which stays the
single owner of the ring and the lighting state, so there is never a second
writer to the SPI/ring.

GATT layout:
  Lighting Control service 0xFF30
    Control 0xFF31  (write, write-without-response, read)  JSON command,
                    mirrors the HTTP /set + /scene API
    State   0xFF32  (read, notify)                         JSON snapshot,
                    mirrors GET /state

The unauthenticated (no bonding) and unencrypted properties of this channel are
the later findings BULB-02 and BULB-03, not part of A1. Onboarding/provisioning
over BLE is BULB-01.
"""

import asyncio
import json
import os
import secrets
import sys
import time
import urllib.request

# dbus-fast is present on the image (CareOtter depends on it). Guard the import
# so the pure command-translation logic (_plan_calls) can be unit-checked in an
# environment without dbus-fast, and so a missing dep degrades to a clean exit
# instead of a procd crash-loop. ponytail: stub is test scaffolding, not a fallback runtime.
try:
    from dbus_fast import Variant, BusType, Message, MessageType
    from dbus_fast.aio import MessageBus
    from dbus_fast.service import (ServiceInterface, method, signal,
                                   dbus_property, PropertyAccess)
    _HAS_DBUS = True
except ImportError:
    _HAS_DBUS = False

    class ServiceInterface:
        def __init__(self, *a, **k):
            pass

    def method(*a, **k):
        def deco(f):
            return f
        return deco

    signal = method
    dbus_property = method

    class PropertyAccess:
        READ = 0

    class Variant:
        def __init__(self, *a, **k):
            pass

CONFIG_PATH = os.environ.get("BULBBEE_CONFIG", "/opt/bulbbee/config.json")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import session_token          # for the device serial exposed in the provisioning read


def _load_config():
    cfg = {"http_port": 8082, "ble_name": "BulbBee", "ble_interval": 1}
    try:
        with open(CONFIG_PATH) as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    return cfg


_CFG = _load_config()
HTTP_PORT = int(_CFG.get("http_port", 8082))
BLE_NAME = str(_CFG.get("ble_name", "BulbBee"))
BLE_INTERVAL = int(os.environ.get("BLE_INTERVAL", _CFG.get("ble_interval", 1)))
# BULB-01: legacy shared PIN value. The default build uses a per-device PIN
# derived from the serial (_derive_pin), not this value, which it rejects.
PROV_PIN = str(_CFG.get("prov_pin", "8080"))
# Credential the BLE plane presents to the single-owner :8082 daemon when it
# forwards a command: in secure mode the daemon gates on this auth token.
AUTH_TOKEN = str(_CFG.get("auth_token", ""))
# BULB-SEC: secure-mode toggle, the ONE defensive option. With secure off (the
# default) the vulnerabilities run as a chain (see docs CHAINS.md): each finding
# yields an artifact and control of the bulb requires composing the links. With
# secure on, every link is closed. There is no instant-win posture.
SECURE = bool(_CFG.get("secure"))

LIGHT_SERVICE_UUID = "0000ff30-0000-1000-8000-00805f9b34fb"
CONTROL_CHAR_UUID = "0000ff31-0000-1000-8000-00805f9b34fb"
STATE_CHAR_UUID = "0000ff32-0000-1000-8000-00805f9b34fb"
# BULB-01: provisioning service (discoverable on connect but not advertised)
PROV_SERVICE_UUID = "0000ff40-0000-1000-8000-00805f9b34fb"
PROV_AUTH_UUID = "0000ff41-0000-1000-8000-00805f9b34fb"
PROV_CONFIG_UUID = "0000ff42-0000-1000-8000-00805f9b34fb"

APP_PATH = "/org/bulbbee/app"
BUS_NAME = "org.bluez"
ADAPTER_PATH = "/org/bluez/hci0"
SERVICE0 = APP_PATH + "/service0"
CONTROL_PATH = SERVICE0 + "/char0"
STATE_PATH = SERVICE0 + "/char1"
SERVICE1 = APP_PATH + "/service1"
PROV_AUTH_PATH = SERVICE1 + "/char0"
PROV_CONFIG_PATH = SERVICE1 + "/char1"
AD_PATH = "/org/bulbbee/advertisement0"
AGENT_PATH = "/org/bulbbee/agent"      # BULB-A2: pairing agent (secure mode only)
HEARTBEAT_FILE = "/tmp/bulbbee/ble_advertising_heartbeat"
PROV_STATE_FILE = "/tmp/bulbbee/provisioning.json"

_system_bus = None
_ad_bus = None
_ad_is_registered = False
_ad_reregister_lock = None
notifying_state = False

# BULB-01: provisioning state. In the chained default a per-device derived PIN
# (not the shared 8080) authenticates, pin_attempts locks out after 5, a session
# is minted on success, and wifi_psk is stored in cleartext (read back by BULB-05).
_prov_state = {
    "authenticated": False,
    "pin_attempts": 0,
    "wifi_ssid": "",
    "wifi_psk": "",
    "cloud_url": "",
    "pair_token": "",
    "session": "",          # BULB-C2: device-bound session minted on chain-mode auth
}


def _log(msg):
    print("[BLE] %s" % msg, flush=True)


# ── BULB-A2: robust pairing helpers (pure, gated by SECURE at call sites) ──

def _gen_passkey() -> int:
    """A fresh random 6-digit Passkey Entry value per pairing. BlueZ expects a
    uint32 in [0, 999999]."""
    return secrets.randbelow(1000000)


def _derive_pin(device_id):
    """BULB-C2 (chain mode): a per-device provisioning PIN derived from the
    enumerable serial plus the shared vendor salt. Not the global 8080, but
    derivable by an attacker who has the serial (BULB-06 recon or a BULB-03 sniff)
    and the derivation routine (reversed from the app, BULB-APP). Pure, so it is
    unit-checkable and the app can mirror it."""
    import hashlib
    h = hashlib.sha256(("%s:%s" % (session_token.VENDOR_SALT, device_id)).encode()).hexdigest()
    return "%04d" % (int(h[:8], 16) % 10000)


def _prov_flags(base, secure):
    """GATT flags for a provisioning characteristic. Default (vulnerable): the
    base flags, usable over an unauthenticated / Just Works link (BULB-01/02).
    Secure (BULB-A2/BULB-SEC): require an LE Secure Connections bonded + MITM
    link, so BlueZ refuses the read/write on an unpaired or Just Works link.
    Pure, so both branches are unit-checkable."""
    if not secure:
        return base
    return [("encrypt-authenticated-" + f) if f in ("read", "write") else f
            for f in base]


# ── localhost HTTP bridge to the :8082 lighting service (single state owner) ──

def _get_state_bytes() -> bytes:
    try:
        with urllib.request.urlopen(
                "http://127.0.0.1:%d/state" % HTTP_PORT, timeout=2) as r:
            return r.read()
    except Exception as e:  # service not up yet, or transient — tolerate
        _log("state fetch failed (%s)" % e)
        return b"{}"


def _post(path: str, obj: dict):
    data = json.dumps(obj).encode()
    # BULB-02: the :8082 owner now requires a device-bound session (default build)
    # or the auth token (secure). The BLE plane has already authenticated the
    # central (derived-PIN provisioning, or LE SC bonding) before a write reaches
    # here, so it presents the device's own credentials to the owner. The session
    # is minted fresh (serial-derived key in default, the chain-forgeable one).
    req = urllib.request.Request(
        "http://127.0.0.1:%d%s" % (HTTP_PORT, path), data=data, method="POST",
        headers={"Content-Type": "application/json",
                 "X-Session": session_token.issue(session_token.device_serial(), secure=False),
                 "X-Auth-Token": AUTH_TOKEN})
    with urllib.request.urlopen(req, timeout=2) as r:
        return r.read()


def _plan_calls(command: dict):
    """Pure: map a control-characteristic JSON command to the HTTP calls it
    triggers. Returns a list of (path, payload). Unit-checkable without BLE."""
    calls = []
    setk = {k: command[k] for k in ("power", "brightness", "color") if k in command}
    if setk:
        calls.append(("/set", setk))
    if "scene" in command:
        calls.append(("/scene", {"scene": command["scene"]}))
    return calls


def _apply_command(command: dict):
    for path, payload in _plan_calls(command):
        try:
            _post(path, payload)
        except Exception as e:
            _log("command forward to %s failed (%s)" % (path, e))


# ── BULB-01: provisioning (unauthenticated onboarding) ──

def _load_prov_state():
    try:
        with open(PROV_STATE_FILE) as f:
            saved = json.load(f)
        for k in ("wifi_ssid", "wifi_psk", "cloud_url", "pair_token"):
            if k in saved:
                _prov_state[k] = saved[k]
    except (OSError, ValueError):
        pass


def _save_prov_state():
    try:
        os.makedirs(os.path.dirname(PROV_STATE_FILE), exist_ok=True)
        with open(PROV_STATE_FILE, "w") as f:
            json.dump({k: _prov_state[k] for k in
                       ("wifi_ssid", "wifi_psk", "cloud_url", "pair_token")}, f)
        if SECURE:                                  # BULB-05 fix: restrictive mode
            os.chmod(PROV_STATE_FILE, 0o600)
    except OSError:
        pass


WIFI_HOOK = "/usr/lib/vulnzoo-hooks/profile-init.d/40-bulbbee-wifi.sh"


def _wifi_set_argv(ssid: str, psk: str):
    """Pure: the uci argv sequence to persist the provisioned station creds in
    the bulbbee_wifi config. A clean argv list, NOT a shell string, so BULB-01
    stays weak-auth only, not command injection. The 40-bulbbee-wifi.sh hook
    turns these creds into the live STA config (radio + wwan + firewall) on
    every boot/load, so the join survives reboots and lab reloads."""
    return [
        ["uci", "set", "bulbbee_wifi.sta=creds"],
        ["uci", "set", "bulbbee_wifi.sta.ssid=%s" % ssid],
        ["uci", "set", "bulbbee_wifi.sta.psk=%s" % psk],
        ["uci", "commit", "bulbbee_wifi"],
    ]


def _do_wifi_set(ssid: str, psk: str):
    import subprocess
    for argv in _wifi_set_argv(ssid, psk):
        try:
            subprocess.run(argv, capture_output=True, timeout=15, check=False)
        except (OSError, subprocess.SubprocessError) as e:
            _log("wifi_set step %r failed (%s)" % (argv[:2], e))
    # Apply the join now via the idempotent hook (it also runs on every boot).
    try:
        subprocess.run([WIFI_HOOK], capture_output=True, timeout=30, check=False,
                       env=dict(os.environ, VULNZOO_DEVICE="bulbbee"))
        _log("wifi hook applied for %s" % ssid)
    except (OSError, subprocess.SubprocessError) as e:
        _log("wifi hook failed (%s)" % e)


TUNNEL_INIT = "/etc/init.d/bulbbee-tunnel"


def _write_cloud_host(host: str, config_path: str = CONFIG_PATH) -> bool:
    """Persist the provisioned cloud server IP into config.json so the outbound
    tunnel (cloud_tunnel.py) dials the real cloud instead of the 192.168.2.10
    default. Pure file I/O, unit-checkable. A cold boot re-extracts the tarball,
    so this is a runtime setting, re-provision after a factory reset."""
    host = str(host).strip()
    if not host:
        return False
    try:
        with open(config_path) as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg["cloud_host"] = host
    try:
        with open(config_path, "w") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        return False
    return True


def _apply_cloud_host(host: str):
    """Write cloud_host into config.json and restart the tunnel so it reconnects
    to the real cloud. Gated by the same (derived) PIN as the rest of
    provisioning, so an attacker in range can also point the bulb at their own
    cloud (the re-provisioning surface, BULB-01 / BULB-P07)."""
    if not _write_cloud_host(host):
        _log("cloud_host not applied (%r)" % host)
        return
    host = str(host).strip()
    _prov_state["cloud_url"] = host
    _save_prov_state()
    _log("cloud_host set to %s in config.json" % host)
    import subprocess
    try:
        subprocess.run([TUNNEL_INIT, "restart"], capture_output=True,
                       timeout=15, check=False)
        _log("cloud tunnel restarted to reconnect to %s" % host)
    except (OSError, subprocess.SubprocessError) as e:
        _log("tunnel restart failed (%s)" % e)


def _prov_auth(pin: str) -> bool:
    """Check the provisioning PIN. Default (vulnerable, BULB-01): a per-device PIN
    derived from the enumerable serial (_derive_pin), lockout after 5 tries, the
    shared 8080 rejected. Secure (BULB-SEC): lock out after 5 and refuse the shared default."""
    if SECURE:
        if _prov_state["pin_attempts"] >= 5:        # BULB-SEC: lockout
            _log("Provisioning AUTH locked out")
            return False
        if pin == "8080":                           # BULB-SEC: refuse the shared default
            _prov_state["pin_attempts"] += 1
            _log("Provisioning AUTH refused (default PIN not allowed in secure mode)")
            return False
        if pin == PROV_PIN:
            _prov_state["authenticated"] = True
            _prov_state["pin_attempts"] = 0
            _log("Provisioning AUTH success")
        else:
            _prov_state["pin_attempts"] += 1
            _log("Provisioning AUTH failed (attempts=%d)" % _prov_state["pin_attempts"])
        return _prov_state["authenticated"]
    # BULB-01 (chained default): a per-device PIN derived from the serial, not the
    # shared 8080, with a lockout after 5 tries. The PIN must be derived (serial
    # from BULB-06 recon or a sniff, plus the routine reversed from the app), so
    # onboarding is a chain link, not a free step. A success mints the device-bound
    # session the control surfaces (BULB-02) require. secure closes this above.
    if _prov_state["pin_attempts"] >= 5:
        _log("Provisioning AUTH locked out")
        return False
    dev = session_token.device_serial()
    if pin != "8080" and pin == _derive_pin(dev):
        _prov_state["authenticated"] = True
        _prov_state["pin_attempts"] = 0
        _prov_state["session"] = session_token.issue(dev, secure=False)
        _log("Provisioning AUTH success (session issued)")
    else:
        _prov_state["pin_attempts"] += 1
        _log("Provisioning AUTH failed (attempts=%d)" % _prov_state["pin_attempts"])
    return _prov_state["authenticated"]


def _prov_apply(cmd: dict):
    """Handle a provisioning command, gated only by the derived-PIN auth."""
    if not _prov_state["authenticated"]:
        _log("Provisioning command rejected — PIN not verified")
        return
    action = cmd.get("cmd")
    if action == "wifi_set":
        ssid = str(cmd.get("ssid", ""))
        psk = str(cmd.get("psk", ""))
        _prov_state["wifi_ssid"] = ssid
        _prov_state["wifi_psk"] = psk
        _save_prov_state()
        _do_wifi_set(ssid, psk)
        if cmd.get("cloud_host"):                    # optional: the real cloud server IP
            _apply_cloud_host(cmd["cloud_host"])
        _log("Provisioning wifi_set: %s" % ssid)
    elif action == "cloud_set":
        _apply_cloud_host(str(cmd.get("cloud_host", "")))
        _log("Provisioning cloud_set: %s" % cmd.get("cloud_host", ""))
    elif action == "pair_set":
        _prov_state["pair_token"] = str(cmd.get("token", ""))
        _prov_state["cloud_url"] = str(cmd.get("cloud_url", ""))
        _save_prov_state()
        _log("Provisioning pair_set")
    else:
        _log("Provisioning: unknown cmd %r" % action)


def _prov_read() -> dict:
    """Read the provisioning state. PIN-gated, then returns the WiFi PSK in
    cleartext (that plaintext read is finding BULB-05)."""
    if not _prov_state["authenticated"]:
        return {"error": "PIN_REQUIRED"}
    if SECURE:                                       # BULB-05 fix: never return the PSK
        return {"device_id": session_token.device_serial(),
                "wifi_ssid": _prov_state["wifi_ssid"], "cloud_url": _prov_state["cloud_url"]}
    # BULB-05 (chained default): hand the minted session to the controller and
    # still disclose the WiFi PSK in cleartext, but only after the derived-PIN auth.
    return {
        "device_id": session_token.device_serial(),  # the app reads this to bind the real device
        "wifi_ssid": _prov_state["wifi_ssid"],
        "wifi_psk": _prov_state["wifi_psk"],
        "cloud_url": _prov_state["cloud_url"],
        "session": _prov_state.get("session", ""),
    }


# ── notifications (hand-emitted PropertiesChanged, as in CareOtter) ──

def _notify_characteristic(path: str, value_bytes: bytes):
    if _system_bus is None:
        return
    try:
        msg = Message(
            message_type=MessageType.SIGNAL,
            interface="org.freedesktop.DBus.Properties",
            path=path,
            member="PropertiesChanged",
            signature="sa{sv}as",
            body=["org.bluez.GattCharacteristic1",
                  {"Value": Variant("ay", value_bytes)},
                  []])
        _system_bus.send(msg)
    except Exception as e:
        _log("_notify_characteristic error: %s" % e)


# ── advertising self-healing (L1), mirrors CareOtter ──

def _write_heartbeat():
    try:
        os.makedirs(os.path.dirname(HEARTBEAT_FILE), exist_ok=True)
        with open(HEARTBEAT_FILE, "w") as f:
            f.write(str(int(time.time())))
    except OSError:
        pass


async def _ensure_advertisement_registered():
    global _ad_reregister_lock, _ad_is_registered
    if _ad_bus is None:
        return
    if _ad_reregister_lock is None:
        _ad_reregister_lock = asyncio.Lock()
    async with _ad_reregister_lock:
        if _ad_is_registered:
            return
        try:
            introspection = await _ad_bus.introspect(BUS_NAME, ADAPTER_PATH)
            manager_obj = _ad_bus.get_proxy_object(BUS_NAME, ADAPTER_PATH, introspection)
            ad_manager = manager_obj.get_interface("org.bluez.LEAdvertisingManager1")
            try:
                await ad_manager.call_register_advertisement(AD_PATH, {})
                _ad_is_registered = True
                _log("Advertising registered")
            except Exception as e:
                if "AlreadyExists" in str(e):
                    _ad_is_registered = True
                    _log("Advertising already registered (reused)")
                else:
                    try:
                        await ad_manager.call_unregister_advertisement(AD_PATH)
                    except Exception:
                        pass
                    await ad_manager.call_register_advertisement(AD_PATH, {})
                    _ad_is_registered = True
                    _log("Advertising registered after cleanup")
        except Exception as e:
            _ad_is_registered = False
            _log("_ensure_advertisement_registered error: %s" % e)


def _schedule_advertisement_reregister():
    try:
        asyncio.ensure_future(_ensure_advertisement_registered())
    except Exception:
        pass


async def _advertising_watchdog():
    _write_heartbeat()
    _log("advertising watchdog armed")
    interval = max(10, int(os.environ.get("BLE_WATCHDOG_INTERVAL", 60)))
    while True:
        await asyncio.sleep(interval)
        await _ensure_advertisement_registered()
        _write_heartbeat()


async def _state_notify_loop():
    """Poll /state and notify subscribed centrals on change."""
    last = None
    while True:
        await asyncio.sleep(BLE_INTERVAL)
        if not notifying_state:
            continue
        cur = _get_state_bytes()
        if cur != last:
            last = cur
            _notify_characteristic(STATE_PATH, cur)


# ── GATT characteristics ──

class ControlChrc(ServiceInterface):
    def __init__(self):
        super().__init__("org.bluez.GattCharacteristic1")
        self.uuid = CONTROL_CHAR_UUID
        self.flags = ["read", "write", "write-without-response"]

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Service(self) -> "o":
        return SERVICE0

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> "as":
        return self.flags

    @dbus_property(access=PropertyAccess.READ)
    def Value(self) -> "ay":
        return _get_state_bytes()

    @method()
    def ReadValue(self, options: "a{sv}") -> "ay":
        return _get_state_bytes()

    @method()
    def WriteValue(self, value: "ay", options: "a{sv}"):
        raw = bytes(value)
        try:
            command = json.loads(raw.decode())
        except (ValueError, UnicodeDecodeError):
            _log("Control WriteValue: bad JSON %r" % raw[:64])
            return
        if not SECURE and not _prov_state.get("authenticated"):
            # BULB-02 (chained default): control converges on a device-bound session,
            # established by the derived-PIN provisioning auth (BULB-01), so an
            # unprovisioned central in range cannot drive the ring. (secure gates
            # on LE SC bonding instead.)
            _log("Control WriteValue dropped (no device-bound session)")
            return
        _log("Control WriteValue: %s" % command)
        _apply_command(command)
        if notifying_state:
            _notify_characteristic(STATE_PATH, _get_state_bytes())


class StateChrc(ServiceInterface):
    def __init__(self):
        super().__init__("org.bluez.GattCharacteristic1")
        self.uuid = STATE_CHAR_UUID
        self.flags = ["read", "notify"]

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Service(self) -> "o":
        return SERVICE0

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> "as":
        return self.flags

    @dbus_property(access=PropertyAccess.READ)
    def Value(self) -> "ay":
        return _get_state_bytes()

    @method()
    def ReadValue(self, options: "a{sv}") -> "ay":
        return _get_state_bytes()

    @method()
    def StartNotify(self):
        global notifying_state
        notifying_state = True
        _log("State notifications enabled")

    @method()
    def StopNotify(self):
        global notifying_state
        notifying_state = False
        _log("State notifications stopped")

    @signal()
    def PropertiesChanged(self, interface: "s", changed: "a{sv}",
                          invalidated: "as") -> "sa{sv}as":
        return [interface, changed, invalidated]


class ProvisioningAuthChrc(ServiceInterface):
    """BULB-01: provisioning auth (0xFF41), the per-device PIN gate.

    Chained default: the PIN is derived per-device from the enumerable serial plus
    a shared vendor salt (not the old global 8080), with a lockout after 5 tries.
    The link is not bonded, and an unauthenticated read of this characteristic
    exposes the serial, so the PIN is derivable (the chain link, with the routine
    reversed from the app) rather than free. secure requires an LE SC bonded link.
    """

    def __init__(self):
        super().__init__("org.bluez.GattCharacteristic1")
        self.uuid = PROV_AUTH_UUID
        # BULB-A2: secure mode requires an authenticated (LE SC bonded) link.
        self.flags = _prov_flags(["read", "write"], SECURE)

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Service(self) -> "o":
        return SERVICE1

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> "as":
        return self.flags

    @dbus_property(access=PropertyAccess.READ)
    def Value(self) -> "ay":
        return json.dumps({"locked": False}).encode()

    @method()
    def ReadValue(self, options: "a{sv}") -> "ay":
        # BULB-01 (chained): the serial is readable before auth (it is enumerable /
        # on the device label), so the per-device PIN is derivable. This is both the
        # legitimate app's and the attacker's way to compute the PIN. secure refuses
        # this read on an unbonded link (encrypt-authenticated flags).
        return json.dumps({"device_id": session_token.device_serial(),
                           "attempts": _prov_state["pin_attempts"],
                           "locked": _prov_state["pin_attempts"] >= 5}).encode()

    @method()
    def WriteValue(self, value: "ay", options: "a{sv}"):
        _prov_auth(bytes(value).decode("utf-8", errors="ignore").strip())


class ProvisioningConfigChrc(ServiceInterface):
    """BULB-01: provisioning commands (0xFF42), gated only by the derived-PIN auth.

    wifi_set reconfigures the station WiFi (a clean uci write, no shell), so an
    attacker in range re-provisions the bulb onto their network. ReadValue
    returns the stored WiFi PSK in cleartext once the PIN gate is passed (that
    plaintext read is finding BULB-05, referenced here as the chain).
    """

    def __init__(self):
        super().__init__("org.bluez.GattCharacteristic1")
        self.uuid = PROV_CONFIG_UUID
        # BULB-A2: secure mode requires an authenticated (LE SC bonded) link.
        self.flags = _prov_flags(["read", "write", "notify"], SECURE)

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Service(self) -> "o":
        return SERVICE1

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> "as":
        return self.flags

    @dbus_property(access=PropertyAccess.READ)
    def Value(self) -> "ay":
        return json.dumps({"provisioned": bool(_prov_state["wifi_ssid"])}).encode()

    @method()
    def ReadValue(self, options: "a{sv}") -> "ay":
        return json.dumps(_prov_read()).encode()

    @method()
    def WriteValue(self, value: "ay", options: "a{sv}"):
        try:
            cmd = json.loads(bytes(value).decode("utf-8", errors="ignore"))
        except (ValueError, UnicodeDecodeError):
            _log("Provisioning: invalid JSON")
            return
        _prov_apply(cmd)

    @method()
    def StartNotify(self):
        pass

    @method()
    def StopNotify(self):
        pass

    @signal()
    def PropertiesChanged(self, interface: "s", changed: "a{sv}",
                          invalidated: "as") -> "sa{sv}as":
        return [interface, changed, invalidated]


class GattService(ServiceInterface):
    def __init__(self, uuid: str, primary: bool = True):
        super().__init__("org.bluez.GattService1")
        self.uuid = uuid
        self.primary = primary
        self.chrcs = []

    def add_characteristic(self, chrc_path: str):
        self.chrcs.append(chrc_path)

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Primary(self) -> "b":
        return self.primary

    @dbus_property(access=PropertyAccess.READ)
    def Characteristics(self) -> "ao":
        return self.chrcs


class Advertisement(ServiceInterface):
    def __init__(self):
        super().__init__("org.bluez.LEAdvertisement1")
        self.type = "peripheral"
        self.local_name = BLE_NAME
        self.service_uuids = [LIGHT_SERVICE_UUID]
        self.flags = ["general-discoverable", "le-only"]
        self.includes = []
        self.min_interval = 100
        self.max_interval = 200

    @dbus_property(access=PropertyAccess.READ)
    def Type(self) -> "s":
        return self.type

    @dbus_property(access=PropertyAccess.READ)
    def LocalName(self) -> "s":
        return self.local_name

    @dbus_property(access=PropertyAccess.READ)
    def ServiceUUIDs(self) -> "as":
        return self.service_uuids

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> "as":
        return self.flags

    @dbus_property(access=PropertyAccess.READ)
    def Includes(self) -> "as":
        return self.includes

    @dbus_property(access=PropertyAccess.READ)
    def MinInterval(self) -> "u":
        return self.min_interval

    @dbus_property(access=PropertyAccess.READ)
    def MaxInterval(self) -> "u":
        return self.max_interval

    @method()
    def Release(self):
        global _ad_is_registered
        _ad_is_registered = False
        _log("Advertising released by BlueZ — reprogramming")
        _schedule_advertisement_reregister()


class ObjectManager(ServiceInterface):
    def __init__(self):
        super().__init__("org.freedesktop.DBus.ObjectManager")
        self.objects = {}

    def add_object(self, path: str, interfaces: dict):
        self.objects[path] = interfaces

    @method()
    def GetManagedObjects(self) -> "a{oa{sa{sv}}}":
        return self.objects


class Agent(ServiceInterface):
    """BlueZ pairing agent. The capability chosen at registration selects the
    method: NoInputNoOutput -> Just Works (no MITM) in the default build (BULB-P01),
    KeyboardDisplay -> LE Secure Connections + Passkey Entry / Numeric Comparison in
    secure mode (BULB-A2). A fresh random passkey is generated per pairing when one
    is requested (KeyboardDisplay); Just Works requests none."""

    def __init__(self):
        super().__init__("org.bluez.Agent1")
        self.session_passkey = 0

    @method()
    def Release(self):
        _log("Pairing agent released")

    @method()
    def RequestPasskey(self, device: "o") -> "u":
        self.session_passkey = _gen_passkey()
        _log("Pairing passkey for %s: %06d" % (device, self.session_passkey))
        return self.session_passkey

    @method()
    def DisplayPasskey(self, device: "o", passkey: "u", entered: "q"):
        _log("Display passkey %06d (entered=%d) for %s" % (passkey, entered, device))

    @method()
    def RequestConfirmation(self, device: "o", passkey: "u"):
        _log("Numeric comparison %06d for %s — confirmed" % (passkey, device))

    @method()
    def RequestAuthorization(self, device: "o"):
        _log("Pairing authorization for %s — granted" % device)

    @method()
    def AuthorizeService(self, device: "o", uuid: "s"):
        _log("Service %s authorized for %s" % (uuid, device))

    @method()
    def Cancel(self):
        _log("Pairing cancelled")


def _force_random_static_address():
    """Pin the LE Random Static Address so the Cypress BCM43430 controller stops
    emitting the AA:AA:AA:AA:AA:AA sentinel. Same workaround as CareOtter."""
    import subprocess
    try:
        out = subprocess.check_output(["hciconfig", "hci0"], timeout=3).decode()
        mac = next((tok for line in out.splitlines() if "BD Address:" in line
                    for tok in line.split() if ":" in tok and len(tok) == 17), None)
        if not mac:
            return
        octets = list(reversed(mac.split(":")))
        subprocess.run(["hcitool", "-i", "hci0", "cmd", "0x08", "0x0005", *octets],
                       capture_output=True, timeout=3, check=False)
        _log("LE_Set_Random_Address -> %s" % mac)
    except Exception as e:
        _log("LE_Set_Random_Address failed: %r" % e)


async def setup_adapter(bus):
    introspection = await bus.introspect(BUS_NAME, ADAPTER_PATH)
    adapter_obj = bus.get_proxy_object(BUS_NAME, ADAPTER_PATH, introspection)
    adapter = adapter_obj.get_interface("org.bluez.Adapter1")
    await adapter.set_alias(BLE_NAME)
    await adapter.set_powered(True)
    await adapter.set_discoverable(True)
    # BULB-P01: the adapter is pairable in both modes. Default (vulnerable) pairs
    # with a NoInputNoOutput agent -> Just Works (no MITM), so a central that insists
    # on pairing can bond while the link still has no real protection. Secure pairs
    # with the LE SC + Passkey agent (BULB-A2).
    await adapter.set_pairable(True)
    _force_random_static_address()
    _log("Adapter configured: %s (pairable=True, %s)" % (
        BLE_NAME, "LE SC + Passkey" if SECURE else "Just Works"))


async def register_app(bus):
    introspection = await bus.introspect(BUS_NAME, ADAPTER_PATH)
    manager_obj = bus.get_proxy_object(BUS_NAME, ADAPTER_PATH, introspection)
    gatt_manager = manager_obj.get_interface("org.bluez.GattManager1")
    await gatt_manager.call_register_application(APP_PATH, {})
    _log("GATT application registered")


async def register_agent(bus, capability):
    """Register the pairing agent as the default agent. The capability selects the
    method: NoInputNoOutput -> Just Works (no MITM, the BULB-P01 default),
    KeyboardDisplay -> LE Secure Connections + Passkey Entry (BULB-A2 secure)."""
    introspection = await bus.introspect(BUS_NAME, "/org/bluez")
    manager_obj = bus.get_proxy_object(BUS_NAME, "/org/bluez", introspection)
    agent_manager = manager_obj.get_interface("org.bluez.AgentManager1")
    await agent_manager.call_register_agent(AGENT_PATH, capability)
    await agent_manager.call_request_default_agent(AGENT_PATH)
    _log("Pairing agent registered as default (%s)" % capability)


async def main():
    _log("Starting BulbBee BLE GATT server (dbus-fast)")
    if not _HAS_DBUS:
        _log("dbus-fast not available — cannot start BLE server, exiting")
        sys.exit(1)

    os.environ.setdefault("DBUS_SYSTEM_BUS_ADDRESS",
                          "unix:path=/run/dbus/system_bus_socket")
    try:
        bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
        global _system_bus, _ad_bus
        _system_bus = bus
        _ad_bus = bus
        _log("Connected to D-Bus: %s" % bus.unique_name)
    except Exception as e:
        _log("Error connecting to D-Bus: %s" % e)
        sys.exit(1)

    _load_prov_state()
    light_service = GattService(LIGHT_SERVICE_UUID)
    control_chrc = ControlChrc()
    state_chrc = StateChrc()
    prov_service = GattService(PROV_SERVICE_UUID, primary=False)  # not advertised
    prov_auth_chrc = ProvisioningAuthChrc()
    prov_config_chrc = ProvisioningConfigChrc()
    obj_manager = ObjectManager()

    bus.export(APP_PATH, obj_manager)
    bus.export(SERVICE0, light_service)
    bus.export(CONTROL_PATH, control_chrc)
    bus.export(STATE_PATH, state_chrc)
    bus.export(SERVICE1, prov_service)
    bus.export(PROV_AUTH_PATH, prov_auth_chrc)
    bus.export(PROV_CONFIG_PATH, prov_config_chrc)

    light_service.add_characteristic(CONTROL_PATH)
    light_service.add_characteristic(STATE_PATH)
    prov_service.add_characteristic(PROV_AUTH_PATH)
    prov_service.add_characteristic(PROV_CONFIG_PATH)

    def _add_svc(path, svc):
        obj_manager.add_object(path, {"org.bluez.GattService1": {
            "UUID": Variant("s", svc.uuid),
            "Primary": Variant("b", svc.primary),
            "Characteristics": Variant("ao", svc.chrcs)}})

    def _add_chrc(path, chrc):
        obj_manager.add_object(path, {"org.bluez.GattCharacteristic1": {
            "UUID": Variant("s", chrc.uuid),
            "Service": Variant("o", chrc.Service),
            "Flags": Variant("as", chrc.flags),
            "Value": Variant("ay", chrc.Value)}})

    _add_svc(SERVICE0, light_service)
    _add_chrc(CONTROL_PATH, control_chrc)
    _add_chrc(STATE_PATH, state_chrc)
    _add_svc(SERVICE1, prov_service)
    _add_chrc(PROV_AUTH_PATH, prov_auth_chrc)
    _add_chrc(PROV_CONFIG_PATH, prov_config_chrc)

    ad = Advertisement()
    bus.export(AD_PATH, ad)

    await setup_adapter(bus)
    await register_app(bus)
    # Always register a pairing agent so the adapter is actually pairable. Default
    # (vulnerable) uses NoInputNoOutput -> Just Works (no MITM, BULB-P01). Secure
    # uses KeyboardDisplay -> LE SC + Passkey (BULB-A2).
    agent = Agent()
    bus.export(AGENT_PATH, agent)
    try:
        await register_agent(bus, "KeyboardDisplay" if SECURE else "NoInputNoOutput")
    except Exception as e:
        _log("Pairing agent registration failed (%s)" % e)
    await _ensure_advertisement_registered()

    _log("Server started, advertising as '%s' (service %s)" % (BLE_NAME, LIGHT_SERVICE_UUID))
    asyncio.create_task(_state_notify_loop())
    asyncio.create_task(_advertising_watchdog())

    while True:
        await asyncio.sleep(1)


def _demo():
    # ponytail: one runnable check for the command-translation logic, no BLE
    assert _plan_calls({"scene": "rainbow"}) == [("/scene", {"scene": "rainbow"})]
    assert _plan_calls({"brightness": 200, "color": [1, 2, 3]}) == \
        [("/set", {"brightness": 200, "color": [1, 2, 3]})]
    both = _plan_calls({"power": True, "scene": "solid"})
    assert both == [("/set", {"power": True}), ("/scene", {"scene": "solid"})]
    assert _plan_calls({}) == []

    # BULB-01 (chained default): wifi_set argv is a clean list (no shell), the PIN
    # is per-device derived (not 8080), locks out after 5, a success mints a session.
    argv = _wifi_set_argv("evil-ap", "p@ss")
    assert argv[1] == ["uci", "set", "bulbbee_wifi.sta.ssid=evil-ap"]
    assert ["uci", "commit", "bulbbee_wifi"] in argv
    _prov_state.update({"authenticated": False, "pin_attempts": 0, "session": "",
                        "wifi_ssid": "", "wifi_psk": "", "cloud_url": "", "pair_token": ""})
    assert _prov_read() == {"error": "PIN_REQUIRED"}          # gated before auth
    dev = session_token.device_serial()
    good = _derive_pin(dev)
    assert good != "8080" and len(good) == 4                  # per-device PIN, not the shared default
    assert _derive_pin("other-serial-xyz") != good or dev == "other-serial-xyz"  # differs by serial
    assert _prov_auth("8080") is False                       # the shared default is refused
    _prov_state["pin_attempts"] = 0
    for _ in range(5):
        assert _prov_auth("0000") is False                   # 5 wrong PINs
    assert _prov_auth(good) is False                         # locked out after 5 attempts
    _prov_state["pin_attempts"] = 0                          # reset the lockout
    assert _prov_auth(good) is True                          # the derived PIN authenticates
    tok = _prov_state["session"]
    assert session_token.confirm(tok, dev, secure=False) is not None   # a real session was minted
    _prov_apply({"cmd": "wifi_set", "ssid": "evil-ap", "psk": "p@ss"})
    assert _prov_state["wifi_ssid"] == "evil-ap" and _prov_state["wifi_psk"] == "p@ss"
    assert _prov_read()["wifi_psk"] == "p@ss"                # BULB-05: PSK in cleartext after auth
    assert _prov_read()["session"] == tok                    # BULB-02: controller receives the session

    # cloud_host provisioning: the real cloud IP is written into config.json
    import tempfile
    tf = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
    json.dump({"cloud_host": "192.168.2.10", "http_port": 8082}, tf)
    tf.close()
    assert _write_cloud_host("", tf.name) is False           # empty ignored, keeps default
    assert _write_cloud_host("10.0.0.5", tf.name) is True
    with open(tf.name) as f:
        after = json.load(f)
    assert after["cloud_host"] == "10.0.0.5"                 # real IP persisted
    assert after["http_port"] == 8082                        # other config untouched
    os.unlink(tf.name)

    # BULB-A2: robust-pairing helpers
    assert _prov_flags(["read", "write"], False) == ["read", "write"]   # default unchanged
    assert _prov_flags(["read", "write", "notify"], True) == \
        ["encrypt-authenticated-read", "encrypt-authenticated-write", "notify"]
    assert _prov_flags(["write-without-response"], True) == ["write-without-response"]
    for _ in range(1000):
        assert 0 <= _gen_passkey() <= 999999                 # passkey in the uint32 6-digit range

    # BULB-03: the provisioning/control flags stay plain in the chained default
    # (SECURE False), so the link is sniffable. Asserted above (_prov_flags(base, False) == base).
    _prov_state.update({"authenticated": False, "pin_attempts": 0, "session": ""})

    print("ble_light self-check OK (_plan_calls + BULB-01/02/05 chained default + BULB-A2 pairing)")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--selfcheck":
        _demo()
    else:
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            pass

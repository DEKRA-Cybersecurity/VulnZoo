# CareOtter Medical Sensor Lab - Hook System Documentation

## Overview

**CareOtter** is a medical IoT laboratory for VulnZoo that simulates a cardiac/pulse oximeter sensor (MAX30102) in OpenWRT running on Raspberry Pi 3B.

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Raspberry Pi 3B (OpenWRT)                │
│                                                             │
│  ┌─────────────────┐    ┌──────────────────┐               │
│  │ sensor_service  │───→│   ble_server     │               │
│  │   HTTP :8081    │    │   BLE GATT       │               │
│  │                 │    │   "CareOtter_HR" │               │
│  └─────────────────┘    └──────────────────┘               │
│           ↑                      ↓                          │
│   /tmp/medical-logs/     ┌──────────────┐                   │
│   vitals.log             │  Mobile App  │                   │
│                          │    (BLE)     │                   │
│                          └──────────────┘                   │
│                                                             │
│  Additional: HTTP API on port 8081 for WiFi connectivity   │
└─────────────────────────────────────────────────────────────┘
```

## Hook Execution Order

Hooks are executed alphabetically by the VulnZoo hook-manager when loading the `careotter` profile.

| Order | Hook | Purpose | Status |
|-------|------|---------|--------|
| 1 | `5-preflight.sh` | System pre-flight checks | ✅ Active |
| 2 | `10-database.sh` | Legacy SQLite init (optional) | ⚠️ Optional (legacy) |
| 3 | `15-python-deps.sh` | Verify Python packages | ✅ Active |
| 4 | `20-bluetooth.sh` | Configure Bluetooth/BLE | ⚠️ Needs firmware |
| 5 | `30-security-policy.sh` | Legacy security profiles | ⚠️ Optional (legacy) |
| 6 | `40-i2c.sh` | Enable I2C for hardware sensor | ✅ Active |
| 7 | `50-medical-sensor.sh` | Start HTTP sensor service | ✅ Active |
| 8 | `55-ble-server.sh` | Start BLE GATT server | ⚠️ Needs Bluetooth |
| 9 | `60-cron.sh` | Configure log rotation | ✅ Active |

## Detailed Hook Descriptions

### 5-preflight.sh
**Purpose:** System verification before loading the lab

**Checks:**
- Directory structure (`/root/careotter/*` for legacy, `/opt/medical-sensor/` for current)
- Python3 availability
- Bluetooth utilities presence
- I2C device availability
- Disk space (>100MB)

**Output:** Logs to `/root/vulnzoo.log`

### 10-database.sh
**Purpose:** Initialize SQLite database for legacy CareOtter

**Behavior:**
- If `/root/careotter/` exists: Initializes SQLite database via `core.data_store`
- If not exists: Skips gracefully (modern sensor uses file-based logging)

**Note:** Modern installation uses `/opt/medical-sensor/` with JSON file logging instead of SQLite.

### 15-python-deps.sh
**Purpose:** Verify Python dependencies

**Required Packages:**
- `bleak` - For BLE functionality
- `pyyaml` - For YAML config parsing
- `aiohttp` - For async HTTP (legacy)
- `smbus2` - For I2C hardware communication

**Missing packages:** Logs warning, does not fail

### 20-bluetooth.sh
**Purpose:** Configure Bluetooth hardware for BLE

**Actions:**
1. Load kernel modules: `bluetooth`, `hci_uart`, `btusb`, `rfcomm`, `btbcm`, `hci_vhci`
2. Check firmware presence (`/lib/firmware/brcm/BCM43430A1.hcd`)
3. Wait for `hci0` device (10 retries)
4. Power on adapter
5. Enable BLE mode
6. Set device name: `CareOtter_HR`
7. Enable discoverable/pairable
8. Enable LE advertising

**Known Issue:** Requires Bluetooth firmware for Raspberry Pi 3 BCM43438 chip. Firmware not included in standard OpenWRT feeds.

**Workaround:** Use HTTP API on port 8081 instead of BLE.

### 30-security-policy.sh
**Purpose:** Apply security policies for training phases

**Profiles:**
- `careotter` (default): Secure - all protections enabled
- `careotter-phase2`: BLE encryption disabled for training
- `careotter-phase3`: OAuth2/API protections disabled
- `careotter-phase4`: Data encryption disabled

**Note:** Only works with legacy `/root/careotter/config/security_policy.yaml`. Modern sensor in `/opt/medical-sensor/` uses `config.json`.

### 40-i2c.sh
**Purpose:** Enable I2C bus for physical MAX30102 sensor

**Actions:**
- Check if `/dev/i2c-1` exists
- Load `i2c-dev` kernel module
- Run `/etc/init.d/i2c` to configure `config.txt` if needed

**Fallback:** If no I2C, sensor uses software simulation via `simulator.py`

### 50-medical-sensor.sh
**Purpose:** Start the main medical sensor HTTP service

**Service Details:**
- **Binary:** `/opt/medical-sensor/sensor_service.py`
- **Port:** 8081 (HTTP)
- **Log:** `/tmp/medical-logs/vitals.log`
- **Init Script:** `/etc/init.d/medical-sensor`

**Endpoints:**
- `GET /vitals` - Current BPM, SpO2, raw values
- `GET /health` - Service health check
- `GET /config` - Active configuration
- `GET /log` - Full log buffer (1440 entries max)
- `GET /log/last` - Most recent entry
- `GET /reload` - Reopen log file (for logrotate)

**Summary Generation:**
- Every 60 seconds (configurable via `summary_every_s`)
- Calculates: min, max, avg for BPM and SpO2
- Writes to log buffer and file

### 55-ble-server.sh
**Purpose:** Start BLE GATT server for mobile app connectivity

**Service Details:**
- **Binary:** `/opt/medical-sensor/ble_server.py`
- **PID File:** `/var/run/careotter-ble.pid`
- **Log:** `/tmp/ble_server.log`

**BLE Characteristics:**
- **Service UUID:** `0000180d-0000-1000-8000-00805f9b34fb` (Heart Rate)
- **HR Measurement:** `00002a37-0000-1000-8000-00805f9b34fb` (Notify/Read)
- **SpO2:** `c0a10001-0000-1000-8000-00805f9b34fb` (Custom, Notify/Read)
- **Battery:** `00002a19-0000-1000-8000-00805f9b34fb` (Read)

**Prerequisites:**
- `bleak` Python package installed
- Bluetooth adapter (`hci0`) available
- Firmware BCM43430A1.hcd present

**Known Issue:** Bluetooth firmware not available in standard OpenWRT packages for RPi3.

### 60-cron.sh
**Purpose:** Configure log rotation for medical logs

**Actions:**
- Enable and start `cron` service
- Add logrotate entry if not present
- Logrotate config: `/etc/logrotate.d/medical-sensor`

**Rotation Policy:**
- Rotate daily or when size > 1MB
- Keep 5 rotated files
- Compress old logs
- Post-rotate: Send SIGUSR1 to Python processes

## File Locations

### Modern Sensor (Current)
```
/opt/medical-sensor/
├── sensor_service.py      # Main HTTP service
├── ble_server.py          # BLE GATT server
├── simulator.py           # MAX30102 simulator
├── config.json            # Configuration
└── requirements.txt       # Python dependencies

/tmp/medical-logs/
└── vitals.log             # Sensor data log (tmpfs)
```

### Legacy Sensor (Optional)
```
/root/careotter/
├── core/                  # Data store, sensor logic
├── api/                   # BLE, cloud sync
├── config/                # YAML configs
├── data/                  # SQLite database
└── logs/                  # Application logs
```

### System Configuration
```
/etc/init.d/medical-sensor      # Init script for HTTP service
/etc/config/vulnzoo             # UCI config with current_device
/root/vulnzoo.log               # Hook execution logs
/usr/lib/vulnzoo-hooks/execution.log  # Hook manager logs
```

## Configuration Files

### /opt/medical-sensor/config.json
```json
{
    "use_real_hardware": false,
    "bpm": 72,
    "spo2": 98,
    "http_port": 8081,
    "sample_rate": 10,
    "log_file": "/tmp/medical-logs/vitals.log",
    "summary_every_s": 60,
    "log_buffer_max": 1440
}
```

### /etc/logrotate.d/medical-sensor
```
/tmp/medical-logs/vitals.log {
    daily
    size 1M
    rotate 5
    compress
    delaycompress
    missingok
    notifempty
    postrotate
        killall -SIGUSR1 python3 2>/dev/null || true
    endscript
}
```

## Troubleshooting

### Bluetooth Not Working (No hci0)

**Symptoms:**
```
hciconfig                          # Empty output
bluetoothctl show                  # "No default controller available"
```

**Cause:** Missing firmware BCM43430A1.hcd for Raspberry Pi 3 BCM43438 chip

**Solution:**
1. Use HTTP API instead (recommended for lab)
2. Or manually download firmware:
   ```bash
   mkdir -p /lib/firmware/brcm
   wget -O /lib/firmware/brcm/BCM43430A1.hcd \
       https://github.com/RPi-Distro/bluez-firmware/raw/master/broadcom/BCM43430A1.hcd
   /etc/init.d/bluetoothd restart
   ```

### Sensor HTTP Not Responding

**Check:**
```bash
ps | grep sensor_service          # Process running?
netstat -tulnp | grep 8081        # Port listening?
curl http://127.0.0.1:8081/health # Health check
cat /root/vulnzoo.log | tail      # Hook execution logs
```

**Restart:**
```bash
/etc/init.d/medical-sensor restart
```

### Hook Failures

**Check execution status:**
```bash
/usr/lib/vulnzoo-hooks/hook-manager.sh status careotter
cat /usr/lib/vulnzoo-hooks/execution.log
```

**Force re-execution:**
```bash
/usr/lib/vulnzoo-hooks/hook-manager.sh init careotter force
```

## Usage Examples

### Read Current Vitals via HTTP
```bash
curl http://192.168.2.100:8081/vitals
# {"bpm": 72, "spo2": 98, "timestamp": 1234567890, ...}
```

### Read Log Buffer
```bash
curl http://192.168.2.100:8081/log
# [{"bpm_avg": 72.5, "spo2_avg": 98.2, ...}, ...]
```

### Trigger Log Rotation
```bash
curl http://192.168.2.100:8081/reload
/usr/sbin/logrotate -f /etc/logrotate.d/medical-sensor
```

## Development Notes

### Hook Idempotency
All hooks check `VULNZOO_DEVICE` environment variable or UCI config before executing:
```bash
VULNZOO_DEVICE="${VULNZOO_DEVICE:-$(uci -q get vulnzoo.state.current_device 2>/dev/null)}"
if [ "$VULNZOO_DEVICE" != "careotter" ]; then
    exit 0
fi
```

### Logging Convention
All hooks log to `/root/vulnzoo.log` with format:
```
YYYY-MM-DD HH:MM:SS [PID] [careotter] Message
```

### Dependencies Between Hooks
- `50-medical-sensor.sh` must run before `55-ble-server.sh` (BLE reads from HTTP)
- `20-bluetooth.sh` must run before `55-ble-server.sh` (BLE needs hci0)
- `40-i2c.sh` is independent (sensor works with or without hardware)

## Security Considerations

### Default Security (careotter profile)
- BLE pairing: secure_passkey (PIN required)
- Encryption: enabled
- HTTP: no auth on local network

### Training Profiles (Optional)
- `careotter-phase2`: BLE JustWorks pairing (insecure)
- `careotter-phase3`: Basic HTTP auth, TLS 1.2
- `careotter-phase4`: No encryption at rest

### Network Exposure
- HTTP port 8081: Exposed to LAN
- No authentication by default
- Suitable for lab/training environment only

## References

- MAX30102 Datasheet: https://datasheets.maximintegrated.com/en/ds/MAX30102.pdf
- OpenWRT Bluetooth: https://openwrt.org/docs/guide-user/hardware/bluetooth/bluetooth.audio
- BLE GATT Services: https://www.bluetooth.com/specifications/gatt/
- VulnZoo Hook System: See `/usr/lib/vulnzoo-hooks/hook-manager.sh`

---

**Last Updated:** 2025-03-17  
**Maintainer:** VulnZoo Project  
**Version:** 2.0 (Modern sensor in /opt/medical-sensor)

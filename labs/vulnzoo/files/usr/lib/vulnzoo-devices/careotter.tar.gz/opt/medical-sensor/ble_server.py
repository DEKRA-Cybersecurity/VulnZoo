#!/usr/bin/env python3
# BLE GATT Server para CareOtter - Expone BPM y SpO2 como servicios estándar

import dbus
import dbus.service
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import GLib
import json
import urllib.request
import signal

DBusGMainLoop(set_as_default=True)

# URLs
SENSOR_URL = "http://127.0.0.1:8081/vitals"

# UUIDs estándar Bluetooth SIG
HR_SERVICE_UUID = "0000180d-0000-1000-8000-00805f9b34fb"
HR_MEASUREMENT_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

PLX_SERVICE_UUID = "00001822-0000-1000-8000-00805f9b34fb"
PLX_CONTINUOUS_UUID = "00002a5f-0000-1000-8000-00805f9b34fb"

BUS_NAME = "org.bluez"
ADAPTER_PATH = "/org/bluez/hci0"
APP_PATH = "/org/careotter/app"

class Application(dbus.service.Object):
    def __init__(self, bus):
        self.path = APP_PATH
        self.services = []
        dbus.service.Object.__init__(self, bus, self.path)
        
    def get_path(self):
        return dbus.ObjectPath(self.path)
    
    def add_service(self, service):
        self.services.append(service)
        
    @dbus.service.method("org.freedesktop.DBus.ObjectManager", out_signature='a{oa{sa{sv}}}')
    def GetManagedObjects(self):
        response = {}
        for service in self.services:
            response[service.get_path()] = service.get_properties()
            for chrc in service.characteristics:
                response[chrc.get_path()] = chrc.get_properties()
        return response

class Service(dbus.service.Object):
    def __init__(self, bus, index, uuid, primary=True):
        self.path = APP_PATH + "/service" + str(index)
        self.bus = bus
        self.uuid = uuid
        self.primary = primary
        self.characteristics = []
        dbus.service.Object.__init__(self, bus, self.path)
        
    def get_path(self):
        return dbus.ObjectPath(self.path)
    
    def get_properties(self):
        return {
            "org.bluez.GattService1": {
                "UUID": self.uuid,
                "Primary": self.primary,
                "Characteristics": dbus.Array(
                    self.get_characteristic_paths(), signature='o')
            }
        }
    
    def get_characteristic_paths(self):
        return [chrc.get_path() for chrc in self.characteristics]
    
    def add_characteristic(self, chrc):
        self.characteristics.append(chrc)

class Characteristic(dbus.service.Object):
    def __init__(self, bus, index, uuid, flags, service):
        self.path = service.path + "/char" + str(index)
        self.bus = bus
        self.uuid = uuid
        self.service = service
        self.flags = flags
        self.notifying = False
        self.value = [0x00]
        dbus.service.Object.__init__(self, bus, self.path)
        GLib.timeout_add_seconds(1, self.update_value)
        
    def get_path(self):
        return dbus.ObjectPath(self.path)
    
    def get_properties(self):
        return {
            "org.bluez.GattCharacteristic1": {
                "Service": self.service.get_path(),
                "UUID": self.uuid,
                "Flags": self.flags,
                "Value": dbus.Array(self.value, signature='y')
            }
        }
    
    def update_value(self):
        """Lee del sensor HTTP y actualiza el valor BLE"""
        try:
            with urllib.request.urlopen(SENSOR_URL, timeout=2) as resp:
                data = json.loads(resp.read())
                
                if self.uuid == HR_MEASUREMENT_UUID:
                    # Formato Heart Rate: [flags, bpm]
                    # flags: bit 0 = 0 (uint8), bit 2-3 = sensor contact detected
                    bpm = int(data.get("bpm", 72))
                    self.value = [0x06, bpm]  # 0x06 = uint8 + contact detected
                    
                elif self.uuid == PLX_CONTINUOUS_UUID:
                    # Formato Pulse Oximeter: [flags, spo2, pr]
                    spo2 = int(data.get("spo2", 98))
                    bpm = int(data.get("bpm", 72))
                    self.value = [0x00, spo2 & 0xFF, bpm & 0xFF]
                    
        except Exception as e:
            print(f"[BLE] Error leyendo sensor: {e}")
            
        if self.notifying:
            self.emit_properties_changed({"Value": dbus.Array(self.value, signature='y')})
            print(f"[BLE] Notificación enviada: {self.value}")
            
        return True  # Repetir cada segundo
    
    @dbus.service.method("org.bluez.GattCharacteristic1", in_signature='', out_signature='ay')
    def ReadValue(self, options):
        return dbus.Array(self.value, signature='y')
    
    @dbus.service.method("org.bluez.GattCharacteristic1", in_signature='ay', out_signature='')
    def WriteValue(self, value, options):
        self.value = value
    
    @dbus.service.method("org.bluez.GattCharacteristic1", in_signature='', out_signature='')
    def StartNotify(self):
        self.notifying = True
        print(f"[BLE] Notificaciones activadas para {self.uuid}")
    
    @dbus.service.method("org.bluez.GattCharacteristic1", in_signature='', out_signature='')
    def StopNotify(self):
        self.notifying = False
    
    @dbus.service.signal("org.freedesktop.DBus.Properties", signature='sa{sv}as')
    def PropertiesChanged(self, interface, changed, invalidated):
        pass
    
    def emit_properties_changed(self, changed):
        self.PropertiesChanged("org.bluez.GattCharacteristic1", changed, [])

def register_app_cb():
    print("[BLE] Aplicación GATT registrada correctamente")

def register_app_error_cb(error):
    print(f"[BLE] Error registrando app: {error}")

def main():
    global bus
    bus = dbus.SystemBus()
    
    # Crear aplicación
    app = Application(bus)
    
    # Servicio de Frecuencia Cardíaca
    hr_service = Service(bus, 0, HR_SERVICE_UUID)
    hr_char = Characteristic(bus, 0, HR_MEASUREMENT_UUID, ["notify", "read"], hr_service)
    hr_service.add_characteristic(hr_char)
    app.add_service(hr_service)
    
    # Servicio de Oxímetro (SpO2)
    plx_service = Service(bus, 1, PLX_SERVICE_UUID)
    plx_char = Characteristic(bus, 0, PLX_CONTINUOUS_UUID, ["notify", "read"], plx_service)
    plx_service.add_characteristic(plx_char)
    app.add_service(plx_service)
    
    # Registrar en BlueZ
    adapter = dbus.Interface(bus.get_object(BUS_NAME, ADAPTER_PATH), "org.bluez.GattManager1")
    adapter.RegisterApplication(app.get_path(), {},
                               reply_handler=register_app_cb,
                               error_handler=register_app_error_cb)
    
    # Configurar advertising
    ad_manager = dbus.Interface(bus.get_object(BUS_NAME, ADAPTER_PATH), "org.bluez.LEAdvertisingManager1")
    
    ad_data = {
        "Type": "peripheral",
        "LocalName": dbus.String("CareOtter"),
        "ServiceUUIDs": dbus.Array([HR_SERVICE_UUID, PLX_SERVICE_UUID], signature='s'),
        "Discoverable": dbus.Boolean(True),
        "IncludeTxPower": dbus.Boolean(True),
    }
    
    ad_path = "/org/careotter/advertisement0"
    ad = dbus.service.Object(bus, ad_path)
    
    # Hacer que el objeto ad implemente la interfaz de advertising (simplificado)
    # En producción completa necesitarías implementar Advertisement1 interface
    
    print("[BLE] Servidor CareOtter iniciado")
    print("[BLE] Servicios: Heart Rate (0x180D) + Pulse Oximeter (0x1822)")
    print("[BLE] Esperando conexiones...")
    
    GLib.MainLoop().run()

if __name__ == "__main__":
    main()